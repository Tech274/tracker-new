// GitHub Sync Test - 2026-02-08
import { Button } from '@/components/ui/button';
import { Trash2, LogOut, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { GlobalSearch } from '@/components/GlobalSearch';
import { LabRequest } from '@/types/labRequest';
import { DeliveryRequest } from '@/types/deliveryRequest';
import { useAuth } from '@/contexts/AuthContext';
import { Badge } from '@/components/ui/badge';
import { ROLE_LABELS, ROLE_COLORS } from '@/types/roles';
import logo from '@/assets/mml-logo.png';

interface HeaderProps {
  requestCount: number;
  onExportCSV: () => void;
  onExportXLS: () => void;
  onClearAll: () => void;
  labRequests: LabRequest[];
  deliveryRequests: DeliveryRequest[];
}

export const Header = ({ requestCount, onClearAll, labRequests, deliveryRequests }: HeaderProps) => {
  const { profile, role, signOut, isAdmin, isOpsLead } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const canClearAll = isAdmin || isOpsLead;

  return (
    <header className="bg-primary border-b sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={logo} alt="MakeMyLabs" className="h-10 object-contain" />
            <div className="hidden sm:block">
              <p className="text-sm text-primary-foreground/80">
                {requestCount} {requestCount === 1 ? 'entry' : 'entries'} recorded
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <GlobalSearch labRequests={labRequests} deliveryRequests={deliveryRequests} />

            {canClearAll && requestCount > 0 && (
              <Button variant="destructive" size="icon" onClick={onClearAll} title="Clear all entries">
                <Trash2 className="w-4 h-4" />
              </Button>
            )}

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" className="bg-accent text-accent-foreground hover:bg-accent/90 gap-2">
                  <User className="w-4 h-4" />
                  <span className="hidden md:inline max-w-[120px] truncate">
                    {profile?.full_name || profile?.email || 'User'}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-1.5">
                  <p className="text-sm font-medium truncate">{profile?.full_name || 'User'}</p>
                  <p className="text-xs text-muted-foreground truncate">{profile?.email}</p>
                  {role && (
                    <Badge className={`mt-2 ${ROLE_COLORS[role]}`} variant="outline">
                      {ROLE_LABELS[role]}
                    </Badge>
                  )}
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};
